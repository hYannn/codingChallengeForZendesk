import requests
import json
import jsonpath
from prettytable import PrettyTable
import cmd
from requests.models import Response
import yaml
import os
import math

def init_connect():
    conf = open("./config.yaml",encoding="UTF-8")
    cfgs = yaml.load(conf,Loader=yaml.FullLoader) 

    url = cfgs['url']
    usr = cfgs['usr']
    pwd = cfgs['pwd']
    # print("{} {} {} ".format(url,usr,pwd))
    response = requests.get(url, auth=(usr, pwd))
    return response

def get_ticketlist(response,data):
    ticket_id = jsonpath.jsonpath(data,"$..id")
    return ticket_id 

def get_ticketlen(response,data):
    ticket_id = jsonpath.jsonpath(data,"$..id")
    return len(ticket_id)

def get_all_tickets(response,data):
    if response.status_code != 200:
        print('Status:', response.status_code, 'Problem with the request. Exiting.')
        return 
    ticket_id = jsonpath.jsonpath(data,"$..id")
    print(ticket_id)
    ticket_subject = jsonpath.jsonpath(data,"$..subject")
    num_ticket = len(ticket_id)
    num_page = math.ceil(num_ticket/25)

    flag2 = 1
    page = 1
    table = PrettyTable(['Id','Subject','Status','Priority'])

    # load all ticket with simply information
    for i in range((page-1)*25,page*25):
        table.add_row([data['tickets'][i]['id'],data['tickets'][i]['subject'],data['tickets'][i]['status'],data['tickets'][i]['priority']])
    print(table)
    page = page+1
    while(flag2!=9):
        print("Do you want to see the next page? Yes: press 1. No: press 2")
        val2 = input("Please input:")
        if(val2 =='1'):
            if(page<=num_page and page!=num_page):
                    table = PrettyTable(['Id','Subject','Status','Priority'])
                    for i in range((page-1)*25,page*25):
                        table.add_row([data['tickets'][i]['id'],data['tickets'][i]['subject'],data['tickets'][i]['status'],data['tickets'][i]['priority']])
                    print(table)
                    page = page +1
            elif(page == num_page):
                table = PrettyTable(['Id','Subject','Status','Priority'])
                for i in range((page-1)*25,num_ticket):
                    table.add_row([data['tickets'][i]['id'],data['tickets'][i]['subject'],data['tickets'][i]['status'],data['tickets'][i]['priority']])
                print(table)
                print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-")
                print("!! No ticket for next page. This is the end.")
                print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-")
                flag2 = 9
            else:
                print("no ticket available")
                flag2 = 9
        if(val2 =='2'):
            flag2 = 9
    return num_page
    
def get_page(num_page):
    return num_page



def get_ticket_detail(input_index,data):
    ticket_id = jsonpath.jsonpath(data,"$..id")
    needed_index = int(input_index)
    if(needed_index in ticket_id):
        real_i = ticket_id.index(needed_index)
        # print the individual ticket
        print("\n")
        print("\n")
        print("*********************************************************")
        print('*ticket id:')
        print(data['tickets'][real_i]['id'])
        print("*Subject:"+"  "+data['tickets'][real_i]['subject'])
        print("*Description:"+"  "+data['tickets'][real_i]['description'])
        print("*Requester_id:"+"  "+str(data['tickets'][real_i]['requester_id']))
        print("*Assignee_id:"+"  "+str(data['tickets'][real_i]['assignee_id']))
        print("*Created_at:"+"  "+data['tickets'][real_i]['created_at'])
        print("*Updated_at:"+"  "+data['tickets'][real_i]['updated_at'])
        print("*********************************************************")
        print("\n")
    else:
        print("*********************************************************")
        print("!!!  There is no ticket with the id. Please try a vaild ticket id.")
        print("*********************************************************")
        print("\n")

if __name__ == "__main__":
    flag = 1
    response = init_connect()
    # Decode the JSON response into a dictionary and use the data
    data = response.json()
    # get the list of ticket_id
    # ticket_id = jsonpath.jsonpath(data,"$..id")
    # ticket_subject = jsonpath.jsonpath(data,"$..subject")
    num_page = 0
    while(flag!=9):
        print("\n")
        print("THIS IS TICKET VIEWER SYSTEM")
        print("1. Input 1 to get all the tickets(25 tickets per page)")
        print("2. Input the id of ticket to get detailed information of the ticket")
        print("0. Input 0 to exit the system")
        val = input("Please input:")
        
        if(val=='1'):
            get_all_tickets(response=response,data=data)
        if(val=='2'):
            input_index = input("Please input the id of the ticket:")
            get_ticket_detail(input_index=input_index,data=data)
        if(val=='0'): 
            print("bye bye~ Now exit")   
            flag = 9









