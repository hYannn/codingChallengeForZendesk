﻿# Ticket viewer system

This is a simple ticket viewer system based on python.
You can get all the tickets from one account and also can get some detailed information about each ticket.
The interface is CLI. So follow the instruction can press the number of your choice.


## Basic environment and running

The program is based on python 3.6 and some packages. 
To use the program, we need to do the following things.

 - Run the command   *pip install -r requirements.txt*  in cmd.
 - Run the command *python run.py* in the file path of run.py in cmd.
 - Follow the instruction to use the program.


## The guide of using the program

 - There are three choices. 
 -Pressing 1 is to show all the tickets. 
  -Pressing 2 is to show the detailed information of one ticket. 
  -Pressing 0 is to exit the program.
 - Only up to 25 tickets can be shown once. So after the first 25 tickets are shown, pressing 1 will show the next 25 tickets, and pressing 2 will stop showing the following tickets.
 

 
 
 


